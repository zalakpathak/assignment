package com.crossover.techtrial.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.crossover.techtrial.exceptions.ArticleException;
import com.crossover.techtrial.model.Article;
import com.crossover.techtrial.repository.ArticleRepository;

@RunWith(SpringRunner.class)
public class ArticleServiceImplTest {

	private ArticleServiceImpl articleService;
	@MockBean
	private ArticleRepository articleRepository;

	@Before
	public void initiate(){
		articleService=new ArticleServiceImpl();
		articleService.setArticleRepository(articleRepository);
	}
	@org.junit.After
	public void destroy(){
		articleService=null;
	}

	@Test
	public void testSaveArticle(){	

		MockitoAnnotations.initMocks(this);			
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title1");		
		Mockito.when(articleRepository.save(anyObject())).thenReturn(article);		
		try {
			articleService.save(article);
		} catch (ArticleException e) {
			assert(false);
		}
	}

	@Test
	public void testSaveArticleWithExceedTitle(){	

		MockitoAnnotations.initMocks(this);			
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title1333333333355555555333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333");		
		Mockito.when(articleRepository.save(anyObject())).thenReturn(article);		
		try {
			articleService.save(article);
			assert(false);
		} catch (ArticleException e) {
			assert(true);
		}
	}

	@Test
	public void testSaveArticleWithExceedContent(){	

		MockitoAnnotations.initMocks(this);			
		Article article=new Article();
		StringBuilder str=new StringBuilder("content");
		for(int j=0;j<1000;j++){
			str.append("1234567890123456789012345689034555555555555555555555555555555554444444");
		}
		article.setContent(str.toString());
		article.setTitle("title1");		
		Mockito.when(articleRepository.save(anyObject())).thenReturn(article);		
		try {
			articleService.save(article);
			assert(false);
		} catch (ArticleException e) {
			assert(true);
		}
	}

	@Test
	public void testDelete(){	

		MockitoAnnotations.initMocks(this);			
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title133333333");				
		Mockito.doNothing().when(articleRepository).deleteById(anyLong());
		articleService.delete(1l);
		assert(true);
	} 


	@Test
	public void testSearch(){	


		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title133333333");
		List<Article> lstArticles=new ArrayList<Article>();
		lstArticles.add(article);
		Mockito.when(articleRepository.findTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(anyString(),anyString())).thenReturn(lstArticles);
		MockitoAnnotations.initMocks(this);		
		List<Article> lstArticlesNew=articleService.search("article");
		assertEquals(true, (lstArticlesNew != null));
		assertEquals(lstArticlesNew.size(),1);
		assertEquals(lstArticles.get(0).getTitle(), lstArticlesNew.get(0).getTitle());

	}  

	@Test
	public void testFindById(){	
		MockitoAnnotations.initMocks(this);			
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title133333333");
		article.setId(1L);
		article.setDate(LocalDateTime.now());
		article.setPublished(true);
		Stream<Article> articleEle= Stream.of(article);
		Mockito.when(articleRepository.findById(anyLong())).thenReturn(articleEle.findAny());
		Article articleReturned=articleService.findById(1L);
		assertEquals(true,articleReturned != null);
		assertEquals(article.getTitle(),articleReturned.getTitle());

	} 

}
