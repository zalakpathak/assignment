package com.crossover.techtrial.controller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.crossover.techtrial.model.Article;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ArticleControllerTest {

	@Autowired
	private TestRestTemplate template;

	@Before
	public void setup() throws Exception {

	}

	@Test
	public void testArticleShouldBeCreated() throws Exception {
		HttpEntity<Object> article = getHttpEntity(
				"{\"email\": \"user1@gmail.com\",\"id\": \"1\", \"title\": \"hello\" }");
		ResponseEntity<Article> resultAsset = template.postForEntity("/articles", article,
				Article.class);
		Assert.assertNotNull(resultAsset.getBody().getId());
	}

	private HttpEntity<Object> getHttpEntity(Object body) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return new HttpEntity<Object>(body, headers);
	}
	@Test
	public void testGetArticleById() throws Exception  {
		
		try {
			ResponseEntity<Article> resultAsset = template.getForEntity("/articles/1",Article.class);
			
		} catch (EmptyResultDataAccessException ex) {		    
		    
		}
		assert(true);
		
	}
	@Test
	public void testUpdateArticle()  {
		HttpEntity<Object> article = getHttpEntity(
				"{\"email\": \"user1@gmail.com\", \"title\": \"hello1\" }");
		ResponseEntity<Article>  resultAsset = template.exchange("/articles/1", HttpMethod.PUT, article, Article.class);
		Assert.assertNotNull(resultAsset.getBody().getId());
	}
	@Test
	public void testDeleteArticle() throws Exception  {
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity httpEntity= new HttpEntity<Object>( headers);
		
		try {
			ResponseEntity<Article> resultAsset  = template.exchange("/articles/1", HttpMethod.DELETE,httpEntity, Article.class);
			
		} catch (EmptyResultDataAccessException ex) {		    
		    
		}
		
		assert(true);
		
	}



}
