package com.crossover.techtrial.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyObject;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.crossover.techtrial.model.Article;
import com.crossover.techtrial.model.Comment;
import com.crossover.techtrial.repository.CommentRepository;

@RunWith(SpringRunner.class)
public class CommentServiceImplTest {

	private CommentServiceImpl commentService;
	@MockBean
	private CommentRepository commentRepository;

	@Before
	public void initiate(){
		commentService=new CommentServiceImpl();
		commentService.setCommentRepository(commentRepository);
	}
	@org.junit.After
	public void destroy(){
		commentService=null;
	}

	@Test
	public void testSaveComment(){	

		MockitoAnnotations.initMocks(this);	
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title133333333");
		article.setId(1L);
		article.setDate(LocalDateTime.now());
		article.setPublished(true);
		Comment comment=new Comment();
		comment.setArticle(article);
		comment.setId(2L);
		comment.setMessage("msg1");
		Mockito.when(commentRepository.save(anyObject())).thenReturn(comment);	
		Comment comment2=commentService.save(comment);
		assertEquals(true,(comment2 != null));

	}

	@Test
	public void testFindAllComments(){	

		MockitoAnnotations.initMocks(this);			
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title133333333");
		article.setId(1L);
		article.setDate(LocalDateTime.now());
		article.setPublished(true);
		Comment comment=new Comment();
		comment.setArticle(article);
		comment.setId(2L);
		comment.setMessage("msg1");
		List<Comment> lst=new ArrayList<Comment>();
		lst.add(comment);
		Mockito.when(commentRepository.findAll()).thenReturn(lst);		

		List<Comment> lstRetrieved=commentRepository.findAll();
		assertEquals(1, lstRetrieved.size());
		assertEquals(lst.get(0).getId(), lstRetrieved.get(0).getId());

	}

}
