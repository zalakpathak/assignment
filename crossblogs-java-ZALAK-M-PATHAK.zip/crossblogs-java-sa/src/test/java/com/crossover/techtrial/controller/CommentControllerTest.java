package com.crossover.techtrial.controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaObjectRetrievalFailureException;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestClientException;

import com.crossover.techtrial.exceptions.GlobalExceptionHandler;
import com.crossover.techtrial.model.Article;
import com.crossover.techtrial.model.Comment;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CommentControllerTest {

	@Autowired
	private TestRestTemplate template;

	@Before
	public void setup() throws Exception {

	}

	@Test
	public void testCommentShouldBeAdded() throws Exception {
		Article article=new Article();
		article.setContent("content1");
		article.setTitle("title133333333");
		article.setId(1L);
		article.setEmail("x@x.com");

		article.setPublished(true);
		Comment comment=new Comment();
		comment.setArticle(article);
		//comment.setId(2L);
		comment.setMessage("msg1");
		comment.setEmail("x@x.com");

		HttpEntity<Object> commentEnt = getHttpEntity(
				convertObjectToJsonBytes(comment));

		ResponseEntity<Article> resultAsset = template.postForEntity("/articles/1/comments/", commentEnt,
				Article.class);
		Assert.assertNotNull(resultAsset.getBody().getId());
	}
	public static byte[] convertObjectToJsonBytes(Object object) throws IOException {		
		return  new ObjectMapper().writeValueAsString(object).getBytes();
	}

	private HttpEntity<Object> getHttpEntity(Object body) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		return new HttpEntity<Object>(body, headers);
	}

	
	@Test
	public void testGetComments()  {		

		try{
		ResponseEntity<List> resultAsset = template.getForEntity("/articles/1/comments",List.class);
		}
		catch(RestClientException e){
			System.out.println(e);
		}
		assert(true);
	}

	
}

