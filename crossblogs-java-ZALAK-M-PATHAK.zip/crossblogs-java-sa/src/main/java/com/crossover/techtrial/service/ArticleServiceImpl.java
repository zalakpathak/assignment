package com.crossover.techtrial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crossover.techtrial.exceptions.ArticleException;
import com.crossover.techtrial.model.Article;
import com.crossover.techtrial.repository.ArticleRepository;

@Service
public class ArticleServiceImpl implements ArticleService {

	@Autowired
	ArticleRepository articleRepository;

	public Article save(Article article) throws ArticleException {

		/**
		 * Though, parameters are validated at controller end,
		 * Putting the business logic of title and content length constraint in service layer as if some other controller 
		 * uses the service,then it should validate the fields.
		 */
		if(article.getTitle() != null && article.getTitle().length() > 120){
			throw new ArticleException("Article Title should have max 120 characters");
		}
		if(article.getContent()!= null && article.getContent().length() > 32000){
			throw new ArticleException("Article Content should have max 32k characters");
		}
		return articleRepository.save(article);
	}

	public Article findById(Long id) {
		return articleRepository.findById(id).orElse(null);
	}

	public void delete(Long id) {
		articleRepository.deleteById(id);
	}

	public List<Article> search(String search) {
		return articleRepository
				.findTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(search, search);
	}

	public ArticleRepository getArticleRepository() {
		return articleRepository;
	}

	public void setArticleRepository(ArticleRepository articleRepository) {
		this.articleRepository = articleRepository;
	}

}